//
//  ViewController.m
//  test
//
//  Created by 孙强 on 2017/9/15.
//  Copyright © 2017年 孙强. All rights reserved.
//

#import "ViewController.h"
#import "SQTableViewCell.h"
#import "SQModel.h"
#define kSize [UIScreen mainScreen].bounds.size

#define kWidth kSize.width

#define kHeight kSize.height

static NSString *const ID = @"cell";

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) NSMutableArray *array;
@property (nonatomic, strong) NSMutableArray *array1;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.array = [NSMutableArray arrayWithCapacity:10];
    self.array1 = [NSMutableArray arrayWithCapacity:10];
    
    for (int i = 0; i < 10; i ++) {
        
        SQModel *model = [[SQModel alloc] init];
        
        model.name = [NSString stringWithFormat:@"名字 %d",i];
        
        model.age = [NSString stringWithFormat:@"年龄 %d",i];
        
        model.adress = [NSString stringWithFormat:@"方里 %d",i];
        
        [self.array addObject:model];
    }
    for (int i = 10; i < 20; i ++) {
        
        SQModel1 *model = [[SQModel1 alloc] init];
        
        model.name = [NSString stringWithFormat:@"名字 %d",i];
        
        model.age = [NSString stringWithFormat:@"年龄 %d",i];
        
        model.adress = [NSString stringWithFormat:@"方里 %d",i];
        
        [self.array1 addObject:model];
    }
   
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, kWidth, kHeight)];
    
    tableView.delegate = self;
    
    tableView.dataSource = self;
    
    [self.view addSubview:tableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    SQTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    
    if (!cell) {
        cell = [[SQTableViewCell alloc] init];
    }
    //下面两个可以注释其中一个 查看效果
    cell.delegate = self.array[indexPath.row];
//    cell.model1 = self.array1[indexPath.row];
    
    return cell;
}

@end
