//
//  SQModel.h
//  test
//
//  Created by 孙强 on 2017/9/15.
//  Copyright © 2017年 孙强. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SQTableViewCell.h"

@interface SQModel : NSObject<SQTableViewDelegate>


@end
