//
//  SQTableViewCell.h
//  test
//
//  Created by 孙强 on 2017/9/15.
//  Copyright © 2017年 孙强. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SQModel1.h"

@protocol SQTableViewDelegate

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *age;

@property (nonatomic, copy) NSString *adress;

@end

@interface SQTableViewCell : UITableViewCell

@property (nonatomic, weak) id<SQTableViewDelegate> delegate;

@property (nonatomic, strong) SQModel1 *model1;

@end
