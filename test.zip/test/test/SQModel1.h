//
//  SQModel1.h
//  test
//
//  Created by 孙强 on 2018/6/9.
//  Copyright © 2018年 孙强. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SQModel1 : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *age;
@property (nonatomic, copy) NSString *adress;

@end
