//
//  SQModel.m
//  test
//
//  Created by 孙强 on 2017/9/15.
//  Copyright © 2017年 孙强. All rights reserved.
//

#import "SQModel.h"

@implementation SQModel

@synthesize name, age, adress;

@end
