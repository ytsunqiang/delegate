//
//  SQTableViewCell.m
//  test
//
//  Created by 孙强 on 2017/9/15.
//  Copyright © 2017年 孙强. All rights reserved.
//

#import "SQTableViewCell.h"

@interface SQTableViewCell ()

@end

@implementation SQTableViewCell

- (void)setModel1:(SQModel1 *)model1 {
    _model1 = model1;
    self.textLabel.text = model1.name;
    self.detailTextLabel.text = model1.age;
}


- (void)setDelegate:(id<SQTableViewDelegate>)delegate {

    _delegate = delegate;
    
    self.textLabel.text = delegate.name;
    self.detailTextLabel.text = delegate.age;
}

@end
