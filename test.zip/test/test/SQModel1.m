//
//  SQModel1.m
//  test
//
//  Created by 孙强 on 2018/6/9.
//  Copyright © 2018年 孙强. All rights reserved.
//

#import "SQModel1.h"

@implementation SQModel1

@end
